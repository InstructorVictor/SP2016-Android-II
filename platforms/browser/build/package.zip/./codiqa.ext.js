// Put your custom code here
(function () {
    "use strict";

    document.addEventListener( 'deviceready', onDeviceReady.bind( this ), false );
    
    function onDeviceReady() {
		console.log("Cordova is ready!");
		navigator.splashscreen.hide();
        // Handle the Cordova pause and resume events
        document.addEventListener( 'pause', onPause.bind( this ), false );
        document.addEventListener( 'resume', onResume.bind( this ), false );

        // TODO: Cordova has been loaded. Perform any initialization that requires Cordova here.
        // document.getElementById("btnURL").onclick = function() {};
		$(".btnURL").on("click", function() { getURL($(this)) });
		function getURL(theURL) { 
			cordova.InAppBrowser.open(theURL.data("url"), "_blank", "location=yes");
		}
    };

    function onPause() {
        // TODO: This application has been suspended. Save application state here.
    };

    function onResume() {
        // TODO: This application has been reactivated. Restore application state here.
    };
} )();